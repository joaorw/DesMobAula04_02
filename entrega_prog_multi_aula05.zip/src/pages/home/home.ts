import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Livro } from '../../model/Livro';
import { InfoLivroPage } from '../info-livro/info-livro';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  public livros: Livro[];

  constructor(public navCtrl: NavController) {
    this.livros = [
      { nome: "ASP.NET MVC", autor: "Fábio Sanchez", img: "../../assets/imgs/asp.png" },
      { nome: "Ciência da Computação", autor: "LTC", img: "../../assets/imgs/cco.png" },
      { nome: "Fundamentos da Programação de Computadores", autor: "Edilene Aparecida Campos", img: "../../assets/imgs/fundamentos.jpg" },
      { nome: "Java Web", autor: "Alexandre Altair de Melo", img: "../../assets/imgs/javaweb.jpg" },
      { nome: "Lógica de Programação", autor: "Paulo Silveira", img: "../../assets/imgs/logica.jpg" },
      { nome: "Programação em Python", autor: "FCA", img: "../../assets/imgs/python.jpg" },
      { nome: "Orientação a Objetos em Java", autor: "Isaias Boratti", img: "../../assets/imgs/orientacaoaobjetos.jpg" },
      { nome: "PHP 5", autor: "Wallace Soares", img: "../../assets/imgs/php5.jpg" },
      {nome: "Programação de Games com Java", autor: "Jonathan Harbour", img: "../../assets/imgs/prog_games.jpg"}
    ];
  }

  goToInfoPage(livro: Livro) {
    this.navCtrl.push(InfoLivroPage, { livroSelecionado: livro });
  }

}
