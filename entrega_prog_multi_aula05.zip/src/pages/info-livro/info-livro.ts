import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Livro } from '../../model/Livro';

/**
 * Generated class for the InfoLivroPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-info-livro',
  templateUrl: 'info-livro.html',
})
export class InfoLivroPage {
  public livro : Livro;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.livro = this.navParams.get ("livroSelecionado");
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad InfoLivroPage');
  }
}
